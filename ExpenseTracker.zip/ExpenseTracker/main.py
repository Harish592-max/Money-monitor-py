import datetime
from fpdf import FPDF

# -----------------------------
# Expense Add Function
# -----------------------------
def add_expense():
    amount = input("Enter expense amount: ").strip()
    if not amount:
        print("❌ Amount cannot be empty.")
        return
    try:
        amount_val = float(amount)  # Validate numeric input
    except ValueError:
        print("❌ Amount must be a number.")
        return

    category = input("Enter category (Food, Travel, etc): ").strip()
    if not category:
        print("❌ Category cannot be empty.")
        return

    date = input("Enter date (DD-MM-YYYY) or press Enter for today: ").strip()
    if not date:
        date = datetime.datetime.now().strftime("%d-%m-%Y")
    else:
        try:
            datetime.datetime.strptime(date, "%d-%m-%Y")  # Validate date format
        except ValueError:
            print("❌ Invalid date format. Use DD-MM-YYYY.")
            return

    if amount_val.is_integer():
        amount_str = f"Rs.{int(amount_val)}"
    else:
        amount_str = f"Rs.{amount_val}"

    entry = f"{date}, {amount_str}, {category}\n"

    try:
        with open("expenses.txt", "a", encoding="utf-8") as file:
            file.write(entry)
        print("✅ Expense saved!")
    except Exception as e:
        print(f"❌ Error saving expense: {e}")

# -----------------------------
# View Expense Records
# -----------------------------
def view_expenses():
    print("\n📋 Your Expenses:")
    try:
        with open("expenses.txt", "r", encoding="utf-8") as file:
            lines = file.readlines()
            if not lines:
                print("⚠️ No expenses recorded yet.")
                return
            total = 0
            for line in lines:
                try:
                    line = line.strip().replace("₹", "Rs.")  # Handle old ₹ format
                    date, amount, category = line.split(", ")
                    amount_val = float(amount.replace("Rs.", ""))
                    total += amount_val
                    print(f"{date}, {amount}, {category}")
                except (ValueError, IndexError):
                    print(f"⚠️ Skipping invalid entry: {line.strip()}")
            print(f"💰 Total Expenses: Rs.{total:.2f}")
    except FileNotFoundError:
        print("⚠️ No expenses file found.")

# -----------------------------
# PDF Generator
# -----------------------------
def generate_pdf():
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", size=12)

    pdf.cell(200, 10, txt="Expense Report", ln=True, align='C')
    pdf.ln(10)
    pdf.cell(60, 10, txt="Date", border=1)
    pdf.cell(60, 10, txt="Amount", border=1)
    pdf.cell(60, 10, txt="Category", border=1)
    pdf.ln()

    try:
        with open("expenses.txt", "r", encoding="utf-8") as file:
            lines = file.readlines()
            if not lines:
                print("⚠️ No expenses found to generate PDF.")
                return
            total = 0
            for line in lines:
                try:
                    line = line.strip().replace("₹", "Rs.")
                    date, amount, category = line.split(", ")
                    day, month, year = date.split("-")
                    date = f"{day.zfill(2)}-{month.zfill(2)}-{year}"
                    amount_val = float(amount.replace("Rs.", ""))
                    if amount_val.is_integer():
                        amount_str = f"Rs.{int(amount_val)}"
                    else:
                        amount_str = f"Rs.{amount_val}"
                    total += amount_val
                    pdf.cell(60, 10, txt=date, border=1)
                    pdf.cell(60, 10, txt=amount_str, border=1)
                    pdf.cell(60, 10, txt=category, border=1)
                    pdf.ln()
                except (ValueError, IndexError):
                    print(f"⚠️ Skipping invalid entry for PDF: {line.strip()}")
            pdf.cell(200, 10, txt=f"Total Expenses: Rs.{total:.2f}", ln=True, align='L')

        try:
            pdf.output("Expense_Report.pdf")
            print("✅ PDF report generated successfully!")
        except Exception as e:
            print(f"❌ Error generating PDF: {e}")
    except FileNotFoundError:
        print("⚠️ No expenses file found. Cannot generate PDF.")

# -----------------------------
# Main Menu
# -----------------------------
def main():
    while True:
        print("\n=== Expense Tracker ===")
        print("1. Add Expense")
        print("2. View Expenses")
        print("3. Generate PDF Report")
        print("Press Enter without typing anything to Exit")
        choice = input("Enter choice: ").strip()

        if choice == "":
            print("👋 Exiting. Goodbye!")
            break
        elif choice == "1":
            add_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            generate_pdf()
        else:
            print("❌ Invalid choice. Try again.")

if __name__ == "__main__":
    main()
