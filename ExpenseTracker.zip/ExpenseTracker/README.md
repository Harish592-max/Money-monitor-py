# Expense Tracker Tool

## Features:
- Daily expense add karo
- Category mention karo
- PDF me full report generate karo

## How to Run:
1. Run `main.py`
2. Select options (Add / View / PDF)
3. PDF file banegi as "Expense_Report.pdf"

## Requirement:
- Python 3.x
- fpdf library (`pip install fpdf`)
